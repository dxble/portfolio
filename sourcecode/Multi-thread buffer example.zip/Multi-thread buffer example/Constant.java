package assignment;

/**
 *
 * @author D.Tea 15909644
 * Constant.java sets the static final int BUFFER_SIZE variable.
 */
public class Constant {
    public static final int BUFFER_SIZE = 5; // Initialize variable
}
